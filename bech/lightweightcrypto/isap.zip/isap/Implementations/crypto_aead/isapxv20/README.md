### Folder Structure:

* **ref**
  * Easy-to-read implementation in C.

