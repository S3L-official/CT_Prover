extern void skinny_128_384_plus_enc (unsigned char* input, const unsigned char* userkey);
