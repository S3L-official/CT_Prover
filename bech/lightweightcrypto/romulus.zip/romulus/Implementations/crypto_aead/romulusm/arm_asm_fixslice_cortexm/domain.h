#ifndef DOMAIN_H_
#define DOMAIN_H_

typedef unsigned char u8;

extern u8 final_ad_domain (unsigned long long adlen, unsigned long long mlen);

#endif  // DOMAIN_H_
